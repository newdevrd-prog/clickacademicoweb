unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  FB4D.Interfaces, 
  FB4D.Firestore,
  FB4D.Authentication,
  FB4D.Document;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    memLog: TMemo;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    procedure AddLog(const Msg: string);
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  DATABASE_NAME = '(default)';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
end;

procedure TFormReplicator.AddLog(const Msg: string);
begin
  memLog.Lines.Add(FormatDateTime('hh:nn:ss', Now) + ' - ' + Msg);
  // Auto-scroll para o fim do log
  SendMessage(memLog.Handle, WM_VSCROLL, SB_BOTTOM, 0);
  Application.ProcessMessages;
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
    Exit;
  end;
  
  if Trim(edtCodTurma.Text) = '' then
  begin
    ShowMessage('Informe o codigo da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  FirestoreDoc: IFirestoreDocument;
  Total: Integer;
  sAluno, sDisc, sSit: string;
  nNota: Double;
begin
  AddLog('--- INICIANDO CONEXAO ---');
  try
    Firestore := TFirestoreDatabase.Create(DATABASE_NAME, FAuth);
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
    
    FDQuery.Close;
    FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
    FDQuery.Open;
    AddLog('Registros encontrados no SQL: ' + FDQuery.RecordCount.ToString);
    
    Total := 0;
    while not FDQuery.Eof do
    begin
      Inc(Total);
      
      // Extraindo dados com tratamento defensivo (Def)
      sAluno := VarToStrDef(FDQuery.FieldByName('Aluno').Value, 'DESCONHECIDO');
      sDisc  := VarToStrDef(FDQuery.FieldByName('Disciplina').Value, 'SEM DISCIPLINA');
      sSit   := VarToStrDef(FDQuery.FieldByName('Situacao').Value, 'N/A');
      
      if FDQuery.FieldByName('1ºBim').IsNull then
        nNota := 0
      else
        nNota := StrToFloatDef(FDQuery.FieldByName('1ºBim').AsString, 0);

      // ADICIONANDO LOG DOS DADOS LIDOS DO FIREBIRD
      AddLog(Format('[%d] Lendo SQL: %s | Disc: %s | Nota: %f', [Total, sAluno, sDisc, nNota]));

      try
        FirestoreDoc := TFirestoreDocument.Create(['notas_alunos'], FIREBASE_PROJECT_ID, DATABASE_NAME);
        
        FirestoreDoc.AddOrUpdateField('aluno', TJSONString.Create(sAluno));
        FirestoreDoc.AddOrUpdateField('disciplina', TJSONString.Create(sDisc));
        FirestoreDoc.AddOrUpdateField('b1_nota', TJSONNumber.Create(nNota));
        FirestoreDoc.AddOrUpdateField('situacao', TJSONString.Create(sSit));
        
        Firestore.InsertOrUpdateDocumentSynchronous(FirestoreDoc);
        
        lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
      except
        on E: Exception do
          AddLog('>> ERRO AO GRAVAR NO FIREBASE (' + sAluno + '): ' + E.Message);
      end;
      
      FDQuery.Next;
    end;
    AddLog('Sucesso: Sincronismo finalizado com ' + Total.ToString + ' registros.');
  except
    on E: Exception do
      AddLog('!!! ERRO CRITICO !!! ' + E.Message);
  end;
end;

end.