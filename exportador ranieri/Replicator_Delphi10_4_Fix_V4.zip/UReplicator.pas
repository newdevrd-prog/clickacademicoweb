unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  // Units da FB4D
  FB4D.Interfaces, 
  FB4D.Configuration, 
  FB4D.Firestore,
  FB4D.Authentication;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  // Substitua pelos seus dados reais do console do Firebase
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  FIREBASE_API_KEY = 'AIzaSyA2-w2UfVhzN2prqJ2H0kecHYwLTC3XbkU';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // CORREÇÃO E2034: O construtor espera apenas UM parâmetro.
  // Como o erro anterior indicou que IFirebaseConfiguration é incompatível com String,
  // passamos apenas o Project ID como String. A API Key é configurada internamente
  // ou via propriedades se necessário.
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo .fdb da base de dados.');
    Exit;
  end;
  
  if Trim(edtCodTurma.Text) = '' then
  begin
    ShowMessage('Informe o código da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  DocObj: TJSONObject;
  Total: Integer;
begin
  // Instancia o Firestore usando o banco padrão e o serviço de autenticação
  Firestore := TFirestoreDatabase.Create('(default)', FAuth);
  
  try 
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro ao abrir base Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    try
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      DocObj.AddPair('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);
      
      // Envio síncrono para o Firebase
      Firestore.InsertDocument('notas_alunos', '', DocObj);
      
      Inc(Total);
      lblStatus.Caption := 'Processados: ' + Total.ToString;
      Application.ProcessMessages;
    except
      on E: Exception do
        lblStatus.Caption := 'Erro: ' + E.Message;
    end;
    FDQuery.Next;
  end;
  
  FDConnection.Connected := False;
  ShowMessage('Replicação concluída com sucesso!' + sLineBreak + 'Total: ' + Total.ToString);
  lblStatus.Caption := 'Pronto.';
end;

end.