unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  FB4D.Interfaces, 
  FB4D.Configuration, 
  FB4D.Firestore, 
  FB4D.Document, 
  System.JSON;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    procedure btnReplicarClick(Sender: TObject);
  private
    FFirebase: IFirebaseConfiguration;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
var
  LServiceAccountJSON: string;
begin
  inherited;
  // Configuração inicial do projeto
  FFirebase := TFirebaseConfiguration.Create(
    'AIzaSyA2-w2UfVhzN2prqJ2H0kecHYwLTC3XbkU', 
    'clickacademico-342da'
  );
  
  // Montagem do JSON da Service Account
  // Nota: O método SetServiceAccount (FB4D.Interfaces) recebe o JSON completo.
  LServiceAccountJSON := 
    '{' +
    '  "type": "service_account",' +
    '  "project_id": "clickacademico-342da",' +
    '  "private_key_id": "7dc4541c0ee0a7af922950af633fa2ad91aa53a2",' +
    '  "client_email": "firebase-adminsdk-fbsvc@clickacademico-342da.iam.gserviceaccount.com",' +
    '  "private_key": "-----BEGIN PRIVATE KEY-----\n' +
    'MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDKiEUnypBd6wfx' +
    'ZM5E/5YNzjcJoJ2sIuAFnBBAipjORv2MJm17Pnh4IQzk3x4Mh+AjKzTmkQRUdmtr' +
    'v+WbV168RF2tPwnhFq5NStkIG2xCuS3S85FgZvfBfsxLEqkLDLPIjmxKrTuUtNgo' +
    'q+Y3Zqe7cKmBAKZ133m1Q3y9L5qeXMS3I09V355p6nJh1Zjms089DgK9rN5unYsu' +
    'k14nuwEZYT98eLhIPeEgffJy8gOTWZq/6KZALnMP2sBZm3LJ2fURHYGWIGHH4y0f' +
    'HXm6MFA5vjEYQTvLZitk6r3ILC1vP714meY9PcTxdU121vRZI8CkhhzfvQ0nDaJ1' +
    'jvR4h3yRAgMBAAECggEACpiFKwcZSnCTYnj9pEp4KpIRUGWgxMgGTwTSgi3ov1H4' +
    'zdjs0rfP9v5I/b2r2sf5B/NTZISjD1rVVTZy6A+dcIgQcTyNDcOcAYXa7jumYaSX' +
    '1c4nBZNy1CKyxB1eeVTZdbKjI70FvZ/rIdBBzmrbzPNLSukidvmRan70tbPEiRMF' +
    'kCgcWipW3GWZ0mLyYrk3bV7qOIPdCkaE3v8amxB112mucJOOk/nvQYpNLHHFY1oG' +
    'MUDMZs+nS7oL93l32jOBbjlE3lu2881KAC6nARrin+yVnoadTQMPmfoNj40psoGu' +
    'mD57tQewlyuAN27SLpIdVH8zOqbRT9mj20yMowkBqQKBgQDow9mjNQM/2h9ja2l6' +
    'mtkdfXZNncrNFC7CB+a2rudEmuxGMu2/DsMxWxCaNGiCKGYMMlcZ97Db0zkSFYWX' +
    '8Bzxr9fO5ERgy63cW8F5KWEJSzyL3aD0gdQSJNJSyOIpnS0P9e9T5ItXRVn6W6U9' +
    '8M5Yr4U69x7ejxAYLsGiJHPwlwKBgQDev9flM4ZtsENAinMhAkNC0+A2Yvmx6+mM' +
    'XEkU0XL0AQ5YikCe9woM162m/BCcdktlfd1iGhhJroTuz9mTfvHA/5vHh3TE8PDW' +
    'gIK9PH8oQj1WJqX3RlulsRBWxIx5BNdpUoB25/+cMuT2//0T7ttpWtssIucOr9yc' +
    'LPzQJPb5FwKBgQCPTWSEUnL5sLR6ZPq/fO4GdeOLzYW51J8k3fBwsCW52xdz8I7m' +
    'fZQ2orYJ+hINcAnDoIp3dkLwU45jT9S7whxPv87BlU9zuHIFpIfsrEkNi8Bu67fY' +
    'UMXblcfXJ831iMrhdKwvnhkbVZsbw6hsBgFEIGuJ7fKXWsSx3rdft8mZaQKBgEEe' +
    'RmhL+tWgPNjmYKfauH0V4askniiEdh9Bb1/1pyxsDpyVtjSCtd5xQuPZNqX28y21' + #10 +
    'cP3X8RfBPD1waAP1jYlFcG4RTHKymUWsBgx6XhYP30yLOeOjHvG+ZK9pAEP0xWCV' +
    '7NZWFmS8gDExPvQP1Pbkx8QMZA3oHY9Om43h8I17AoGBAOKglDwiugFg4/oZ8CH5' +
    's/D/O86yQLA/j8AKQv+XUy3YH277kEE/5TdAdPDRcspz4IIGrKvP3p8F0hNZKrZd' +
    '7fIa41uP12Xn95fsSOyQGp7XO1P9ZXKk96+1wXqksZ2+zmLlQaLJC0fiju7ZiBFM' +
    'gyTcjxMTn+YEKn49rUsV3GtS\n' +
    '-----END PRIVATE KEY-----\n"' +
    '}';

  FFirebase.SetServiceAccount(LServiceAccountJSON);
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if edtCodTurma.Text = '' then Exit;
  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreService;
  DocObj: TJSONObject;
  Total: Integer;
begin
  Firestore := FFirebase.Firestore; 
  
  try
    FDConnection.Connected := True;
    FDQuery.Close;
    FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
    FDQuery.Open;
    
    Total := 0;
    while not FDQuery.Eof do
    begin
      DocObj := TJSONObject.Create;
      try
        DocObj.AddPair('codCur', TJSONNumber.Create(FDQuery.FieldByName('CodCur').AsInteger));
        DocObj.AddPair('curso', FDQuery.FieldByName('Curso').AsString);
        DocObj.AddPair('turma', FDQuery.FieldByName('Turma').AsString);
        DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
        DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);

        // Correção do Typecast para campos BCD/Decimais do Firebird usando .AsFloat
        DocObj.AddPair('bim1_media', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
        DocObj.AddPair('bim2_media', TJSONNumber.Create(FDQuery.FieldByName('2ºBim').AsFloat));
        DocObj.AddPair('bim3_media', TJSONNumber.Create(FDQuery.FieldByName('3ºBim').AsFloat));
        DocObj.AddPair('bim4_media', TJSONNumber.Create(FDQuery.FieldByName('4ºBim').AsFloat));
        DocObj.AddPair('media_anual', TJSONNumber.Create(FDQuery.FieldByName('M.A.').AsFloat));
        DocObj.AddPair('media_final', TJSONNumber.Create(FDQuery.FieldByName('M.A.F.').AsFloat));
        
        DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);
        DocObj.AddPair('last_sync', FormatDateTime('yyyy-mm-dd hh:nn:ss', Now));

        Firestore.Collection('notas_alunos').Insert(DocObj);
        
        Inc(Total);
        lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
        Application.ProcessMessages;
      except
        on E: Exception do 
          lblStatus.Caption := 'Erro no registro: ' + E.Message;
      end;
      FDQuery.Next;
    end;
    ShowMessage('Sucesso! ' + Total.ToString + ' registros sincronizados.');
  except
    on E: Exception do
      ShowMessage('Erro na conexão ou consulta: ' + E.Message);
  end;
end;

end.