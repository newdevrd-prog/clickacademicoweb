object FormReplicator: TFormReplicator
  Caption = 'Replicator v1.0'
  ClientHeight = 350
  ClientWidth = 500
  object CardPanel: TCardPanel
    Align = alClient
    ActiveCard = CardLogin
    object CardLogin: TCard
      object btnConectar: TButton
        Caption = 'Logar no Firebase'
        OnClick = btnConectarClick
      end
    end
    object CardMain: TCard
      object edtCodTurma: TEdit
        Text = '0'
      end
      object btnReplicar: TButton
        Caption = 'Replicar Dados'
        OnClick = btnReplicarClick
      end
      object lblStatus: TLabel
        Caption = 'Pronto'
      end
    end
  end
  object FDConnection: TFDConnection
    Params.Strings = (
      'DriverID=FB'
      'Database=C:\DADOS.FDB')
  end
  object FDQuery: TFDQuery
    Connection = FDConnection
    SQL.Strings = (
      'SELECT '
      '  m.Aluno, d.Disciplina, d."1ºBim", d.F1B, d."2ºBim", d.F2B, '
      '  d."3ºBim", d.F3B, d."4ºBim", d.F4B, d."M.A.F.", d.Situacao'
      'FROM MATRICULA m'
      'INNER JOIN DISCIPLINAS d ON d.CodMat = m.CodMat'
      'WHERE m.CodTur = :CodTur')
  end
end