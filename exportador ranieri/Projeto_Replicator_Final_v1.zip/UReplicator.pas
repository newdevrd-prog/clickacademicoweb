unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, 
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  Vcl.WinXPanels, System.JSON,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param, FireDAC.Stan.Error, 
  FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async, 
  FireDAC.DApt, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  FB4D.Interfaces, FB4D.Configuration, FB4D.Firestore, FB4D.Document, FB4D.Helpers;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    CardPanel: TCardPanel;
    CardLogin: TCard;
    CardMain: TCard;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    lblStatus: TLabel;
    btnConectar: TButton;
    procedure btnReplicarClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnConectarClick(Sender: TObject);
  private
    FConfig: IFirebaseConfiguration;
    procedure OnDocumentInserted(Doc: IFirestoreDocument);
    procedure OnFirestoreError(const RequestID, ErrMsg: string);
  public
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

procedure TFormReplicator.FormCreate(Sender: TObject);
begin
  FConfig := TFirebaseConfiguration.Create('SUA_API_KEY', 'clickacademico-342da');
  CardPanel.ActiveCard := CardLogin;
end;

procedure TFormReplicator.btnConectarClick(Sender: TObject);
begin
  CardPanel.ActiveCard := CardMain;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
var
  Firestore: IFirestoreService;
  DocObj: TJSONObject;
begin
  btnReplicar.Enabled := False;
  Firestore := FConfig.Firestore;
  
  FDConnection.Connected := True;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;

  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    // Mapeamento Completo
    DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
    DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
    DocObj.AddPair('n1', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
    DocObj.AddPair('f1', TJSONNumber.Create(FDQuery.FieldByName('F1B').AsInteger));
    DocObj.AddPair('n2', TJSONNumber.Create(FDQuery.FieldByName('2ºBim').AsFloat));
    DocObj.AddPair('f2', TJSONNumber.Create(FDQuery.FieldByName('F2B').AsInteger));
    DocObj.AddPair('media_final', TJSONNumber.Create(FDQuery.FieldByName('M.A.F.').AsFloat));
    DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);

    Firestore.Collection('notas').Insert(DocObj, OnDocumentInserted, OnFirestoreError);
    FDQuery.Next;
    Application.ProcessMessages;
  end;
  btnReplicar.Enabled := True;
end;

procedure TFormReplicator.OnDocumentInserted(Doc: IFirestoreDocument);
begin
  lblStatus.Caption := 'Documento Sincronizado: ' + Doc.DocumentName;
end;

procedure TFormReplicator.OnFirestoreError(const RequestID, ErrMsg: string);
begin
  lblStatus.Caption := 'Erro: ' + ErrMsg;
end;

end.