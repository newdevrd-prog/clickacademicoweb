unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  FB4D.Interfaces,
  FB4D.Firestore,
  FB4D.Authentication,
  FB4D.Configuration,
  FB4D.Document;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    memLog: TMemo;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    FConfig: IFirebaseConfiguration;
    procedure AddLog(const Msg: string);
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // Substitua pelo seu Project ID real
  FAuth := TFirebaseAuthentication.Create('clickacademico-342da');
  FConfig := TFirebaseConfiguration.Create('clickacademico-342da', '', FAuth);
end;

procedure TFormReplicator.AddLog(const Msg: string);
begin
  TThread.Queue(nil, procedure begin
    memLog.Lines.Add(FormatDateTime('hh:nn:ss', Now) + ' - ' + Msg);
    SendMessage(memLog.Handle, WM_VSCROLL, SB_BOTTOM, 0);
  end);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
    Exit;
  end;
  
  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestore;
  DocIn, DocOut: IFirestoreDocument;
  Total: Integer;
begin
  AddLog('--- INICIANDO SINCRONIZAÇÃO v19.0 ---');
  try
    Firestore := FConfig.Firestore; 
    
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
    
    FDQuery.Close;
    FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
    FDQuery.Open;
    
    AddLog('Registros encontrados: ' + FDQuery.RecordCount.ToString);
    
    Total := 0;
    while not FDQuery.Eof do
    begin
      Inc(Total);
      try
        // Criar objeto de documento para envio
        DocIn := TFirestoreDocument.Create(['notas_alunos']);
        
        // Adicionar campos (Verificado em FB4D.Document.pas)
        DocIn.AddOrUpdateField('aluno', TJSONString.Create(FDQuery.FieldByName('Aluno').AsString));
        DocIn.AddOrUpdateField('disciplina', TJSONString.Create(FDQuery.FieldByName('Disciplina').AsString));
        DocIn.AddOrUpdateField('situacao', TJSONString.Create(FDQuery.FieldByName('Situacao').AsString));
        DocIn.AddOrUpdateField('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
        
        // Enviar para o Firestore de forma síncrona
        // IFirestore.InsertDocument retorna o documento criado
        DocOut := Firestore.InsertDocument(DocIn);
        
        if Assigned(DocOut) then
          AddLog(Format('[%d] Sincronizado: %s', [Total, FDQuery.FieldByName('Aluno').AsString]))
        else
          AddLog(Format('[%d] Erro ao obter resposta do servidor', [Total]));

        TThread.Synchronize(nil, procedure begin
           lblStatus.Caption := 'Processados: ' + Total.ToString;
        end);
      except
        on E: Exception do
          AddLog('Erro no registro ' + Total.ToString + ': ' + E.Message);
      end;
      
      FDQuery.Next;
      Application.ProcessMessages;
    end;
    AddLog('--- PROCESSO CONCLUÍDO ---');
  except
    on E: Exception do
      AddLog('ERRO CRÍTICO: ' + E.Message);
  end;
end;

end.