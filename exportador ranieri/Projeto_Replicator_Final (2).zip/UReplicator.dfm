object FormReplicator: TFormReplicator
  Left = 0
  Top = 0
  Caption = 'Replicator Nativo v3.1'
  ClientHeight = 580
  ClientWidth = 550
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  TextHeight = 15
  object pnlHeader: TPanel
    Left = 0
    Top = 0
    Width = 550
    Height = 200
    Align = alTop
    BevelOuter = bvNone
    Color = clWhite
    ParentBackground = False
    TabOrder = 0
    object lblTurma: TLabel
      Left = 24
      Top = 88
      Width = 98
      Height = 15
      Caption = 'C'#243'digo da Turma:'
    end
    object lblCaminho: TLabel
      Left = 24
      Top = 24
      Width = 120
      Height = 15
      Caption = 'Ficheiro Firebird (.FDB):'
    end
    object lblStatus: TLabel
      Left = 24
      Top = 172
      Width = 505
      Height = 15
      Alignment = taCenter
      AutoSize = False
      Caption = 'Seleccione o banco e clique em sincronizar'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clHotLight
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object btnReplicar: TButton
      Left = 135
      Top = 109
      Width = 394
      Height = 50
      Caption = 'INICIAR REPLICA'#199#195'O'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 0
      OnClick = btnReplicarClick
    end
    object edtCodTurma: TEdit
      Left = 24
      Top = 109
      Width = 105
      Height = 50
      Alignment = taCenter
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -24
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      NumbersOnly = True
      ParentFont = False
      TabOrder = 1
      Text = '1'
    end
    object edtCaminhoFDB: TEdit
      Left = 24
      Top = 45
      Width = 409
      Height = 23
      ReadOnly = True
      TabOrder = 2
    end
    object btnSelFDB: TButton
      Left = 439
      Top = 44
      Width = 90
      Height = 25
      Caption = 'Procurar...'
      TabOrder = 3
      OnClick = btnSelFDBClick
    end
  end
  object memLog: TMemo
    Left = 0
    Top = 200
    Width = 550
    Height = 380
    Align = alClient
    Color = clBlack
    Font.Charset = ANSI_CHARSET
    Font.Color = clLime
    Font.Height = -13
    Font.Name = 'Consolas'
    Font.Style = []
    ParentFont = False
    ReadOnly = True
    ScrollBars = ssVertical
    TabOrder = 1
  end
  object FDConnection: TFDConnection
    Params.Strings = (
      'DriverID=FB'
      'User_Name=SYSDBA'
      'Password=masterkey'
      'CharacterSet=UTF8')
    LoginPrompt = False
    Left = 464
    Top = 232
  end
  object FDQuery: TFDQuery
    Connection = FDConnection
    SQL.Strings = (
      'SELECT '
      '  A.NOME AS Aluno, '
      '  D.NOME AS Disciplina,'
      '  NAT.MEDIA_1B AS Bim1, '
      '  S.NOME AS Situacao'
      'FROM NOTAALUNOTURMA NAT'
      'INNER JOIN ALUNO A ON A.CODIGO = NAT.CODIGOALUNO'
      'INNER JOIN DISCIPLINA D ON D.CODIGO = NAT.CODIGODISCIPLINA'
      'INNER JOIN SITUACAO S ON S.CODIGO = NAT.CODIGOSITUACAO'
      'WHERE NAT.CODIGOTURMA = :CodTur')
    Left = 464
    Top = 288
    ParamData = <
      item
        Name = 'CODTUR'
        DataType = ftInteger
        ParamType = ptInput
      end>
  end
  object FDPhysFBDriverLink1: TFDPhysFBDriverLink
    Left = 464
    Top = 344
  end
  object OpenDialogFDB: TOpenDialog
    DefaultExt = 'fdb'
    Filter = 'Firebird Database (*.fdb)|*.fdb|Todos os ficheiros (*.*)|*.*'
    Title = 'Seleccione o Banco de Dados Click Acad'#234'mico'
    Left = 376
    Top = 232
  end
end