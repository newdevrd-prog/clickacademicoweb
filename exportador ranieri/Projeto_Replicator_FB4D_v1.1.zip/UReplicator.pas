unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, 
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  Vcl.WinXPanels, System.JSON,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param, FireDAC.Stan.Error, 
  FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async, 
  FireDAC.DApt, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  // Unidades da FB4D conforme seus fontes
  FB4D.Interfaces, FB4D.Configuration, FB4D.Firestore, FB4D.Document, FB4D.Helpers;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    CardPanel: TCardPanel;
    CardLogin: TCard;
    CardMain: TCard;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    lblStatus: TLabel;
    btnConectar: TButton;
    procedure btnReplicarClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnConectarClick(Sender: TObject);
  private
    FConfig: IFirebaseConfiguration;
    // Callback ajustado para IFirestoreDocument conforme FB4D.Interfaces
    procedure OnDocumentInserted(Doc: IFirestoreDocument);
    procedure OnFirestoreError(const RequestID, ErrMsg: string);
  public
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

procedure TFormReplicator.FormCreate(Sender: TObject);
begin
  // Inicialização baseada em FB4D.Configuration.pas
  FConfig := TFirebaseConfiguration.Create('SUA_API_KEY', 'clickacademico-342da');
  CardPanel.ActiveCard := CardLogin;
end;

procedure TFormReplicator.btnConectarClick(Sender: TObject);
begin
  CardPanel.ActiveCard := CardMain;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
var
  Firestore: IFirestore; // Corrigido de IFirestoreService para IFirestore
  DocObj: TJSONObject;
begin
  btnReplicar.Enabled := False;
  Firestore := FConfig.Firestore;
  
  FDConnection.Connected := True;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;

  try
    while not FDQuery.Eof do
    begin
      DocObj := TJSONObject.Create;
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      DocObj.AddPair('n1', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      DocObj.AddPair('f1', TJSONNumber.Create(FDQuery.FieldByName('F1B').AsInteger));
      DocObj.AddPair('media_final', TJSONNumber.Create(FDQuery.FieldByName('M.A.F.').AsFloat));

      // Na FB4D, Firestore.InsertDocument espera a coleção e o objeto JSON
      Firestore.InsertDocument('notas', '', DocObj, OnDocumentInserted, OnFirestoreError);
      
      FDQuery.Next;
      Application.ProcessMessages;
    end;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.OnDocumentInserted(Doc: IFirestoreDocument);
begin
  lblStatus.Caption := 'Sincronizado: ' + Doc.DocumentName;
end;

procedure TFormReplicator.OnFirestoreError(const RequestID, ErrMsg: string);
begin
  lblStatus.Caption := 'Erro Firestore: ' + ErrMsg;
end;

end.