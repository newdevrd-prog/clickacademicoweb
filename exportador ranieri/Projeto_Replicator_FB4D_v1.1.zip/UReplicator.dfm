object FormReplicator: TFormReplicator
  Left = 0
  Top = 0
  Caption = 'Replicator v1.1'
  ClientHeight = 350
  ClientWidth = 500
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object CardPanel: TCardPanel
    Left = 0
    Top = 0
    Width = 500
    Height = 350
    Align = alClient
    ActiveCard = CardLogin
    Caption = 'CardPanel'
    TabOrder = 0
    object CardLogin: TCard
      Left = 1
      Top = 1
      Width = 498
      Height = 348
      Caption = 'CardLogin'
      CardIndex = 0
      TabOrder = 0
      object btnConectar: TButton
        Left = 160
        Top = 144
        Width = 161
        Height = 41
        Caption = 'Conectar ao Firebase'
        TabOrder = 0
        OnClick = btnConectarClick
      end
    end
    object CardMain: TCard
      Left = 1
      Top = 1
      Width = 498
      Height = 348
      Caption = 'CardMain'
      CardIndex = 1
      TabOrder = 1
      object lblStatus: TLabel
        Left = 32
        Top = 216
        Width = 33
        Height = 13
        Caption = 'Pronto'
      end
      object edtCodTurma: TEdit
        Left = 32
        Top = 48
        Width = 121
        Height = 21
        TabOrder = 0
        Text = '100'
      end
      object btnReplicar: TButton
        Left = 32
        Top = 88
        Width = 121
        Height = 33
        Caption = 'Enviar para Nuvem'
        TabOrder = 1
        OnClick = btnReplicarClick
      end
    end
  end
  object FDConnection: TFDConnection
    Params.Strings = (
      'DriverID=FB'
      'Database=C:\SeuCaminho\DADOS.FDB'
      'User_Name=sysdba'
      'Password=masterkey')
    LoginPrompt = False
  end
  object FDQuery: TFDQuery
    Connection = FDConnection
    SQL.Strings = (
      'SELECT '
      '  m.Aluno, d.Disciplina, d."1ºBim", d.F1B, d."2ºBim", d.F2B, '
      '  d."3ºBim", d.F3B, d."4ºBim", d.F4B, d."M.A.F.", d.Situacao'
      'FROM MATRICULA m'
      'INNER JOIN DISCIPLINAS d ON d.CodMat = m.CodMat'
      'WHERE m.CodTur = :CodTur')
    Left = 400
    Top = 48
  end
end