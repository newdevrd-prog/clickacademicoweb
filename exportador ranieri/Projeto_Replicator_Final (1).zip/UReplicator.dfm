object FormReplicator: TFormReplicator
  Left = 0
  Top = 0
  Caption = 'Replicador Firebird -> Firebase (VCL)'
  ClientHeight = 220
  ClientWidth = 350
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 15
  object pnlMain: TPanel
    Left = 25
    Top = 20
    Width = 300
    Height = 180
    BevelOuter = bvNone
    TabOrder = 0
    object Label1: TLabel
      Left = 10
      Top = 10
      Width = 168
      Height = 15
      Caption = 'Código da Turma para Replicar:'
    end
    object lblStatus: TLabel
      Left = 10
      Top = 145
      Width = 280
      Height = 15
      Alignment = taCenter
      AutoSize = False
      Caption = 'Aguardando comando...'
    end
    object edtCodTurma: TEdit
      Left = 10
      Top = 35
      Width = 280
      Height = 23
      NumbersOnly = True
      TabOrder = 0
    end
    object btnReplicar: TButton
      Left = 10
      Top = 75
      Width = 280
      Height = 45
      Caption = 'Iniciar Replicação'
      TabOrder = 1
      OnClick = btnReplicarClick
    end
  end
  object FDConnection: TFDConnection
    Params.Strings = (
      'DriverID=FB'
      'User_Name=sysdba'
      'Password=masterkey'
      'Database=C:\Banco.fdb')
    LoginPrompt = False
    Left = 40
    Top = 150
  end
  object FDQuery: TFDQuery
    Connection = FDConnection
    SQL.Strings = (
      'SELECT m.CodCur, m.Curso, m.Turma, m.Aluno, d.Disciplina, '
      'd."1ºBim", d."2ºBim", d."3ºBim", d."4ºBim", d."M.A.", d."M.A.F.", d.Situacao '
      'FROM MATRICULA m INNER JOIN DISCIPLINAS d ON d.CodMat = m.CodMat '
      'WHERE m.CodTur = :CodTur')
    Left = 110
    Top = 150
    ParamData = <
      item
        Name = 'CODTUR'
        DataType = ftInteger
        ParamType = ptInput
      end>
  end
end