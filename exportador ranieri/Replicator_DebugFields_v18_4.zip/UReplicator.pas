unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  FB4D.Interfaces, 
  FB4D.Firestore,
  FB4D.Authentication,
  FB4D.Document;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    memLog: TMemo;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    procedure AddLog(const Msg: string);
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  DATABASE_NAME = '(default)';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
end;

procedure TFormReplicator.AddLog(const Msg: string);
begin
  TThread.Queue(nil, procedure begin
    memLog.Lines.Add(FormatDateTime('hh:nn:ss', Now) + ' - ' + Msg);
    SendMessage(memLog.Handle, WM_VSCROLL, SB_BOTTOM, 0);
  end);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
    Exit;
  end;
  
  btnReplicar.Enabled := False;
  ReplicarParaFirebase;
  btnReplicar.Enabled := True;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  FirestoreDoc: IFirestoreDocument;
  Total: Integer;
  sAluno, sDisc, sSit, sNotaStr: string;
  fNota: Double;
begin
  AddLog('--- INICIANDO CONEXAO ---');
  try
    Firestore := TFirestoreDatabase.Create(DATABASE_NAME, FAuth);
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
    
    FDQuery.Close;
    FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
    FDQuery.Open;
    AddLog('Registros encontrados no SQL: ' + FDQuery.RecordCount.ToString);
    
    Total := 0;
    while not FDQuery.Eof do
    begin
      Inc(Total);
      
      try
        // Lendo e registrando Aluno
        sAluno := VarToStrDef(FDQuery.FieldByName('Aluno').Value, 'DESCONHECIDO');
        AddLog(Format('[%d] -> Convertendo campo "ALUNO": %s', [Total, sAluno]));
        
        // Lendo e registrando Disciplina
        sDisc := VarToStrDef(FDQuery.FieldByName('Disciplina').Value, 'SEM DISCIPLINA');
        AddLog(Format('[%d] -> Convertendo campo "DISCIPLINA": %s', [Total, sDisc]));
        
        // Lendo e registrando Situacao
        sSit := VarToStrDef(FDQuery.FieldByName('Situacao').Value, 'N/A');
        AddLog(Format('[%d] -> Convertendo campo "SITUACAO": %s', [Total, sSit]));
        
        // Tratamento da Nota com log de progresso
        fNota := FDQuery.FieldByName('1ºBim').AsFloat;
        sNotaStr := StringReplace(FloatToStr(fNota), ',', '.', [rfReplaceAll]);
        if sNotaStr = '' then sNotaStr := '0';
        AddLog(Format('[%d] -> Convertendo campo "NOTA": %s', [Total, sNotaStr]));

        // Criar documento
        FirestoreDoc := TFirestoreDocument.Create(['notas_alunos'], FIREBASE_PROJECT_ID, DATABASE_NAME);
        
        // Adicionando campos individualmente com logs
        AddLog('   >> Montando JSON Aluno...');
        FirestoreDoc.AddOrUpdateField('aluno', TJSONString.Create(sAluno));
        
        AddLog('   >> Montando JSON Disciplina...');
        FirestoreDoc.AddOrUpdateField('disciplina', TJSONString.Create(sDisc));
        
        AddLog('   >> Montando JSON Situacao...');
        FirestoreDoc.AddOrUpdateField('situacao', TJSONString.Create(sSit));
        
        AddLog('   >> Montando JSON Nota (Number)...');
        FirestoreDoc.AddOrUpdateField('b1_nota', TJSONNumber.Create(sNotaStr));
        
        // Gravando no Firebase
        AddLog('   >> Gravando no Firestore...');
        Firestore.InsertOrUpdateDocumentSynchronous(FirestoreDoc);
        
        AddLog(Format('[%d] SUCESSO: %s gravado.', [Total, sAluno]));

        TThread.Synchronize(nil, procedure begin
           lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
        end);
      except
        on E: Exception do
          AddLog('>> ERRO AO GRAVAR (' + sAluno + '): ' + E.Message);
      end;
      
      FDQuery.Next;
      Application.ProcessMessages;
    end;
    AddLog('--- FINALIZADO PROCESSO ---');
  except
    on E: Exception do
      AddLog('!!! ERRO DE CONEXAO/SQL !!! ' + E.Message);
  end;
end;

end.