unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  // Units FB4D para Firestore
  FB4D.Interfaces, 
  FB4D.Firestore,
  FB4D.Authentication;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // FAuth inicializado apenas com ProjectID para evitar incompatibilidade de argumentos
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo de banco de dados (.fdb)');
    Exit;
  end;
  
  if Trim(edtCodTurma.Text) = '' then
  begin
    ShowMessage('Informe o código da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  DocObj: TJSONObject;
  Total: Integer;
begin
  // Criação da instância do Firestore Database
  Firestore := TFirestoreDatabase.Create('(default)', FAuth);
  
  try 
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    try
      // Mapeamento dos campos
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      DocObj.AddPair('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);
      DocObj.AddPair('data_sinc', TJSONString.Create(FormatDateTime('yyyy-mm-dd hh:nn:ss', Now)));
      
      { 
        CORREÇÃO E2003: 
        O identificador 'InsertDocument' foi substituído por 'Insert'.
        IFirestoreDatabase.Insert(CollectionPath, DocumentID, JSONObject)
      }
      Firestore.Insert('notas_alunos', '', DocObj);
      
      Inc(Total);
      lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
      Application.ProcessMessages;
    except
      on E: Exception do
        lblStatus.Caption := 'Erro: ' + E.Message;
    end;
    FDQuery.Next;
  end;
  
  FDConnection.Connected := False;
  ShowMessage('Processo concluído com sucesso!' + sLineBreak + 'Total de registros: ' + Total.ToString);
  lblStatus.Caption := 'Pronto.';
end;

end.