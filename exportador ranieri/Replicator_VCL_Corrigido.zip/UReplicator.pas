unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  // Units FB4D
  FB4D.Interfaces, 
  FB4D.Configuration, 
  FB4D.Firestore;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FFirebase: IFirebaseConfiguration;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
var
  LKey: string;
begin
  inherited;
  // Chave privada formatada para evitar erros de concatenação
  LKey := '-----BEGIN PRIVATE KEY-----' + sLineBreak +
          'MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDKiEUnypBd6wfx' + sLineBreak +
          'ZM5E/5YNzjcJoJ2sIuAFnBBAipjORv2MJm17Pnh4IQzk3x4Mh+AjKzTmkQRUdmtr' + sLineBreak +
          'v+WbV168RF2tPwnhFq5NStkIG2xCuS3S85FgZvfBfsxLEqkLDLPIjmxKrTuUtNgo' + sLineBreak +
          'q+Y3Zqe7cKmBAKZ133m1Q3y9L5qeXMS3I09V355p6nJh1Zjms089DgK9rN5unYsu' + sLineBreak +
          'k14nuwEZYT98eLhIPeEgffJy8gOTWZq/6KZALnMP2sBZm3LJ2fURHYGWIGHH4y0f' + sLineBreak +
          'HXm6MFA5vjEYQTvLZitk6r3ILC1vP714meY9PcTxdU121vRZI8CkhhzfvQ0nDaJ1' + sLineBreak +
          'jvR4h3yRAgMBAAECggEACpiFKwcZSnCTYnj9pEp4KpIRUGWgxMgGTwTSgi3ov1H4' + sLineBreak +
          'zdjs0rfP9v5I/b2r2sf5B/NTZISjD1rVVTZy6A+dcIgQcTyNDcOcAYXa7jumYaSX' + sLineBreak +
          '1c4nBZNy1CKyxB1eeVTZdbKjI70FvZ/rIdBBzmrbzPNLSukidvmRan70tbPEiRMF' + sLineBreak +
          'kCgcWipW3GWZ0mLyYrk3bV7qOIPdCkaE3v8amxB112mucJOOk/nvQYpNLHHFY1oG' + sLineBreak +
          'MUDMZs+nS7oL93l32jOBbjlE3lu2881KAC6nARrin+yVnoadTQMPmfoNj40psoGu' + sLineBreak +
          'mD57tQewlyuAN27SLpIdVH8zOqbRT9mj20yMowkBqQKBgQDow9mjNQM/2h9ja2l6' + sLineBreak +
          'mtkdfXZNncrNFC7CB+a2rudEmuxGMu2/DsMxWxCaNGiCKGYMMlcZ97Db0zkSFYWX' + sLineBreak +
          '8Bzxr9fO5ERgy63cW8F5KWEJSzyL3aD0gdQSJNJSyOIpnS0P9e9T5ItXRVn6W6U9' + sLineBreak +
          '8M5Yr4U69x7ejxAYLsGiJHPwlwKBgQDev9flM4ZtsENAinMhAkNC0+A2Yvmx6+mM' + sLineBreak +
          'XEkU0XL0AQ5YikCe9woM162m/BCcdktlfd1iGhhJroTuz9mTfvHA/5vHh3TE8PDW' + sLineBreak +
          'gIK9PH8oQj1WJqX3RlulsRBWxIx5BNdpUoB25/+cMuT2//0T7ttpWtssIucOr9yc' + sLineBreak +
          'LPzQJPb5FwKBgQCPTWSEUnL5sLR6ZPq/fO4GdeOLzYW51J8k3fBwsCW52xdz8I7m' + sLineBreak +
          'fZQ2orYJ+hINcAnDoIp3dkLwU45jT9S7whxPv87BlU9zuHIFpIfsrEkNi8Bu67fY' + sLineBreak +
          'UMXblcfXJ831iMrhdKwvnhkbVZsbw6hsBgFEIGuJ7fKXWsSx3rdft8mZaQKBgEEe' + sLineBreak +
          'RmhL+tWgPNjmYKfauH0V4askniiEdh9Bb1/1pyxsDpyVtjSCtd5xQuPZNqX28y21' + sLineBreak +
          'cP3X8RfBPD1waAP1jYlFcG4RTHKymUWsBgx6XhYP30yLOeOjHvG+ZK9pAEP0xWCV' + sLineBreak +
          '7NZWFmS8gDExPvQP1Pbkx8QMZA3oHY9Om43h8I17AoGBAOKglDwiugFg4/oZ8CH5' + sLineBreak +
          's/D/O86yQLA/j8AKQv+XUy3YH277kEE/5TdAdPDRcspz4IIGrKvP3p8F0hNZKrZd' + sLineBreak +
          '7fIa41uP12Xn95fsSOyQGp7XO1P9ZXKk96+1wXqksZ2+zmLlQaLJC0fiju7ZiBFM' + sLineBreak +
          'gyTcjxMTn+YEKn49rUsV3GtS' + sLineBreak +
          '-----END PRIVATE KEY-----';

  // Na versão mais nova, criamos a configuração e as credenciais são tratadas internamente 
  // ou via objeto de autenticação. 
  FFirebase := TFirebaseConfiguration.Create(
    'AIzaSyA2-w2UfVhzN2prqJ2H0kecHYwLTC3XbkU', 
    'clickacademico-342da'
  );

  // Se o método direto falhar, a FB4D costuma usar o arquivo JSON. 
  // Caso sua versão não tenha o SetServiceAccountCredentials, ela usa a autenticação pelo auth service.
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if edtCaminhoFDB.Text = '' then begin
    ShowMessage('Selecione o arquivo .fdb');
    Exit;
  end;
  
  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreService;
  DocObj: TJSONObject;
  Total: Integer;
begin
  Firestore := TFirestoreService.Create(FFirebase);
  
  try 
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    try
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      DocObj.AddPair('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      
      // Envio para o Firebase
      Firestore.InsertDocument('notas_alunos', '', DocObj);
      
      Inc(Total);
      lblStatus.Caption := 'Sincronizando: ' + Total.ToString;
      Application.ProcessMessages;
    except
    end;
    FDQuery.Next;
  end;
  
  ShowMessage('Fim! Total: ' + Total.ToString);
end;

end.