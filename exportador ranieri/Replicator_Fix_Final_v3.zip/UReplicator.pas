unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  // Units da FB4D
  FB4D.Interfaces, 
  FB4D.Configuration, 
  FB4D.Firestore,
  FB4D.Authentication;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FConfig: IFirebaseConfiguration;
    FAuth: IFirebaseAuthentication;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  FIREBASE_API_KEY = 'AIzaSyA2-w2UfVhzN2prqJ2H0kecHYwLTC3XbkU';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // 1. A configuração é criada apenas com a API Key e ProjectID
  FConfig := TFirebaseConfiguration.Create(FIREBASE_API_KEY, FIREBASE_PROJECT_ID);
  
  // 2. CORREÇÃO: O construtor de Autenticação na FB4D moderna 
  // muitas vezes espera o Project ID ou pode ser criado via Factory.
  // Tentaremos a assinatura mais compatível:
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID, FIREBASE_API_KEY);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Arquivo Firebird não encontrado.');
    Exit;
  end;
  
  if Trim(edtCodTurma.Text) = '' then
  begin
    ShowMessage('Informe o código da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  DocObj: TJSONObject;
  Total: Integer;
begin
  // CORREÇÃO: Ordem dos parâmetros para TFirestoreDatabase.Create
  // Normalmente: DatabaseID (string), Auth (interface)
  Firestore := TFirestoreDatabase.Create('(default)', FAuth);
  
  try 
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    try
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      DocObj.AddPair('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);
      
      // Inserção no Firestore
      Firestore.InsertDocument('notas_alunos', '', DocObj);
      
      Inc(Total);
      lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
      Application.ProcessMessages;
    except
      on E: Exception do
        lblStatus.Caption := 'Erro no ID ' + Total.ToString + ': ' + E.Message;
    end;
    FDQuery.Next;
  end;
  
  FDConnection.Connected := False;
  ShowMessage(' Replicação Concluída!' + sLineBreak + 'Registros: ' + Total.ToString);
  lblStatus.Caption := 'Pronto.';
end;

end.