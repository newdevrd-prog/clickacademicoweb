unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  FB4D.Interfaces, FB4D.Configuration, FB4D.Services, FB4D.Document, System.JSON;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FFirebase: IFirebaseConfiguration;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // Configuração Global Firebase
  FFirebase := TFirebaseConfiguration.Create(
    'AIzaSyA2-w2UfVhzN2prqJ2H0kecHYwLTC3XbkU', 
    'clickacademico-342da'
  );
  
  // Service Account para permissão de escrita
  FFirebase.SetServiceAccountCredentials(
    'firebase-adminsdk-fbsvc@clickacademico-342da.iam.gserviceaccount.com',
    '7dc4541c0ee0a7af922950af633fa2ad91aa53a2',
    '-----BEGIN PRIVATE KEY-----' + #10 +
    'MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDKiEUnypBd6wfx' + #10 +
    'ZM5E/5YNzjcJoJ2sIuAFnBBAipjORv2MJm17Pnh4IQzk3x4Mh+AjKzTmkQRUdmtr' + #10 +
    'v+WbV168RF2tPwnhFq5NStkIG2xCuS3S85FgZvfBfsxLEqkLDLPIjmxKrTuUtNgo' + #10 +
    'q+Y3Zqe7cKmBAKZ133m1Q3y9L5qeXMS3I09V355p6nJh1Zjms089DgK9rN5unYsu' + #10 +
    'k14nuwEZYT98eLhIPeEgffJy8gOTWZq/6KZALnMP2sBZm3LJ2fURHYGWIGHH4y0f' + #10 +
    'HXm6MFA5vjEYQTvLZitk6r3ILC1vP714meY9PcTxdU121vRZI8CkhhzfvQ0nDaJ1' + #10 +
    'jvR4h3yRAgMBAAECggEACpiFKwcZSnCTYnj9pEp4KpIRUGWgxMgGTwTSgi3ov1H4' + #10 +
    'zdjs0rfP9v5I/b2r2sf5B/NTZISjD1rVVTZy6A+dcIgQcTyNDcOcAYXa7jumYaSX' + #10 +
    '1c4nBZNy1CKyxB1eeVTZdbKjI70FvZ/rIdBBzmrbzPNLSukidvmRan70tbPEiRMF' + #10 +
    'kCgcWipW3GWZ0mLyYrk3bV7qOIPdCkaE3v8amxB112mucJOOk/nvQYpNLHHFY1oG' + #10 +
    'MUDMZs+nS7oL93l32jOBbjlE3lu2881KAC6nARrin+yVnoadTQMPmfoNj40psoGu' + #10 +
    'mD57tQewlyuAN27SLpIdVH8zOqbRT9mj20yMowkBqQKBgQDow9mjNQM/2h9ja2l6' + #10 +
    'mtkdfXZNncrNFC7CB+a2rudEmuxGMu2/DsMxWxCaNGiCKGYMMlcZ97Db0zkSFYWX' + #10 +
    '8Bzxr9fO5ERgy63cW8F5KWEJSzyL3aD0gdQSJNJSyOIpnS0P9e9T5ItXRVn6W6U9' + #10 +
    '8M5Yr4U69x7ejxAYLsGiJHPwlwKBgQDev9flM4ZtsENAinMhAkNC0+A2Yvmx6+mM' + #10 +
    'XEkU0XL0AQ5YikCe9woM162m/BCcdktlfd1iGhhJroTuz9mTfvHA/5vHh3TE8PDW' + #10 +
    'gIK9PH8oQj1WJqX3RlulsRBWxIx5BNdpUoB25/+cMuT2//0T7ttpWtssIucOr9yc' + #10 +
    'LPzQJPb5FwKBgQCPTWSEUnL5sLR6ZPq/fO4GdeOLzYW51J8k3fBwsCW52xdz8I7m' + #10 +
    'fZQ2orYJ+hINcAnDoIp3dkLwU45jT9S7whxPv87BlU9zuHIFpIfsrEkNi8Bu67fY' + #10 +
    'UMXblcfXJ831iMrhdKwvnhkbVZsbw6hsBgFEIGuJ7fKXWsSx3rdft8mZaQKBgEEe' + #10 +
    'RmhL+tWgPNjmYKfauH0V4askniiEdh9Bb1/1pyxsDpyVtjSCtd5xQuPZNqX28y21' + #10 +
    'cP3X8RfBPD1waAP1jYlFcG4RTHKymUWsBgx6XhYP30yLOeOjHvG+ZK9pAEP0xWCV' + #10 +
    '7NZWFmS8gDExPvQP1Pbkx8QMZA3oHY9Om43h8I17AoGBAOKglDwiugFg4/oZ8CH5' + #10 +
    's/D/O86yQLA/j8AKQv+XUy3YH277kEE/5TdAdPDRcspz4IIGrKvP3p8F0hNZKrZd' + #10 +
    '7fIa41uP12Xn95fsSOyQGp7XO1P9ZXKk96+1wXqksZ2+zmLlQaLJC0fiju7ZiBFM' + #10 +
    'gyTcjxMTn+YEKn49rUsV3GtS' + #10 +
    '-----END PRIVATE KEY-----'
  );
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if edtCaminhoFDB.Text = '' then begin
     ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
     Exit;
  end;
  
  if edtCodTurma.Text = '' then begin
     ShowMessage('Informe o código da turma.');
     Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreService;
  DocObj: TJSONObject;
  Total: Integer;
begin
  Firestore := TFirebaseService.CreateFirestore(FFirebase);
  
  try 
    // Atualiza o caminho do banco antes de conectar
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    try
      // Identificadores e Mapeamento do SQL informado
      DocObj.AddPair('codCur', TJSONNumber.Create(FDQuery.FieldByName('CodCur').AsInteger));
      DocObj.AddPair('curso', FDQuery.FieldByName('Curso').AsString);
      DocObj.AddPair('turma', FDQuery.FieldByName('Turma').AsString);
      DocObj.AddPair('ano', TJSONNumber.Create(FDQuery.FieldByName('Ano').AsInteger));
      DocObj.AddPair('turno', FDQuery.FieldByName('Turno').AsString);
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('nascimento', FDQuery.FieldByName('Nascimento').AsString);
      DocObj.AddPair('endereco_rua', FDQuery.FieldByName('Rua').AsString);
      DocObj.AddPair('endereco_num', FDQuery.FieldByName('Numero').AsString);
      DocObj.AddPair('naturalidade', FDQuery.FieldByName('Naturalidade').AsString);
      DocObj.AddPair('bairro', FDQuery.FieldByName('Bairro').AsString);
      DocObj.AddPair('cidade', FDQuery.FieldByName('Cidade').AsString);
      DocObj.AddPair('pai', FDQuery.FieldByName('Pai').AsString);
      DocObj.AddPair('mae', FDQuery.FieldByName('Mae').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      
      DocObj.AddPair('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      DocObj.AddPair('b1_faltas', TJSONNumber.Create(FDQuery.FieldByName('F1B').AsInteger));
      DocObj.AddPair('b2_nota', TJSONNumber.Create(FDQuery.FieldByName('2ºBim').AsFloat));
      DocObj.AddPair('b2_faltas', TJSONNumber.Create(FDQuery.FieldByName('F2B').AsInteger));
      DocObj.AddPair('b3_nota', TJSONNumber.Create(FDQuery.FieldByName('3ºBim').AsFloat));
      DocObj.AddPair('b3_faltas', TJSONNumber.Create(FDQuery.FieldByName('F3B').AsInteger));
      DocObj.AddPair('b4_nota', TJSONNumber.Create(FDQuery.FieldByName('4ºBim').AsFloat));
      DocObj.AddPair('b4_faltas', TJSONNumber.Create(FDQuery.FieldByName('F4B').AsInteger));
      
      DocObj.AddPair('media_anual', TJSONNumber.Create(FDQuery.FieldByName('M.A.').AsFloat));
      DocObj.AddPair('prova_final', TJSONNumber.Create(FDQuery.FieldByName('P.F.').AsFloat));
      DocObj.AddPair('media_final', TJSONNumber.Create(FDQuery.FieldByName('M.A.F.').AsFloat));
      DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);
      DocObj.AddPair('sync_at', TJSONString.Create(FormatDateTime('yyyy-mm-dd hh:nn:ss', Now)));

      Firestore.InsertDocument('notas_alunos', '', DocObj);
      
      Inc(Total);
      lblStatus.Caption := 'Sincronizando: ' + Total.ToString;
      Application.ProcessMessages;
    finally 
    end;
    FDQuery.Next;
  end;
  
  ShowMessage('Processo concluído! ' + Total.ToString + ' registros enviados.');
  lblStatus.Caption := 'Pronto.';
end;

end.