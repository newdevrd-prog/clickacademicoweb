object FormReplicator: TFormReplicator
  Left = 0
  Top = 0
  Caption = 'Replicator Final - Firebird -> Firebase'
  ClientHeight = 280
  ClientWidth = 400
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  object pnlMain: TPanel
    Left = 25
    Top = 15
    Width = 350
    Height = 245
    BevelOuter = bvNone
    TabOrder = 0
    object Label1: TLabel
      Left = 10
      Top = 75
      Width = 168
      Height = 15
      Caption = 'Código da Turma para Replicar:'
    end
    object Label2: TLabel
      Left = 10
      Top = 10
      Width = 143
      Height = 15
      Caption = 'Arquivo do Banco Firebird:'
    end
    object lblStatus: TLabel
      Left = 10
      Top = 215
      Width = 330
      Height = 15
      Alignment = taCenter
      AutoSize = False
      Caption = 'Pronto para replicar.'
    end
    object edtCodTurma: TEdit
      Left = 10
      Top = 95
      Width = 330
      Height = 23
      NumbersOnly = True
      TabOrder = 0
    end
    object btnReplicar: TButton
      Left = 10
      Top = 140
      Width = 330
      Height = 60
      Caption = 'ENVIAR PARA FIREBASE'
      Font.Style = [fsBold]
      TabOrder = 1
      OnClick = btnReplicarClick
    end
    object edtCaminhoFDB: TEdit
      Left = 10
      Top = 30
      Width = 250
      Height = 23
      ReadOnly = True
      TabOrder = 2
    end
    object btnProcurarFDB: TButton
      Left = 266
      Top = 29
      Width = 75
      Height = 25
      Caption = 'Procurar...'
      TabOrder = 3
      OnClick = btnProcurarFDBClick
    end
  end
  object FDConnection: TFDConnection
    Params.Strings = (
      'DriverID=FB'
      'User_Name=SYSDBA'
      'Password=masterkey'
      'CharacterSet=UTF8')
    LoginPrompt = False
    Left = 48
    Top = 208
  end
  object FDQuery: TFDQuery
    Connection = FDConnection
    SQL.Strings = (
      'Select '
      '  A.NOME as Aluno, D.Nome as Disciplina,'
      '  Media_1b as "1'#186'Bim", S.Nome as Situacao '
      'From NotaAlunoTurma NAT'
      'inner join Situacao S on S.Codigo = NAT.CodigoSituacao'
      'inner join Aluno a on NAT.codigoaluno = A.codigo'
      'inner join Disciplina D on d.codigo = NAT.codigodisciplina'
      'where CodigoTurma = :CodTur'
      'order by A.Nome, D.Codigo')
    Left = 120
    Top = 208
    ParamData = <
      item
        Name = 'CODTUR'
        DataType = ftInteger
        ParamType = ptInput
      end>
  end
  object OpenDialog: TOpenDialog
    DefaultExt = 'fdb'
    Filter = 'Firebird (*.fdb)|*.fdb'
    Left = 200
    Top = 208
  end
  object FDPhysFBDriverLink1: TFDPhysFBDriverLink
    Left = 280
    Top = 208
  end
end