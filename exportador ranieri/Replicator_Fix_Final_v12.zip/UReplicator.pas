unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  FB4D.Interfaces, 
  FB4D.Firestore,
  FB4D.Authentication,
  FB4D.Document;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  DATABASE_NAME = '(default)';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
    Exit;
  end;
  
  if Trim(edtCodTurma.Text) = '' then
  begin
    ShowMessage('Informe o codigo da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  FirestoreDoc: TFirestoreDocument; // Usando a classe diretamente para acessar metodos de conveniencia
  Total: Integer;
  ValNota: Double;
begin
  Firestore := TFirestoreDatabase.Create(DATABASE_NAME, FAuth);
  
  try 
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    // Criamos a instancia da classe TFirestoreDocument
    FirestoreDoc := TFirestoreDocument.Create(['notas_alunos'], FIREBASE_PROJECT_ID, DATABASE_NAME);
    try
      {
        IMPORTANTE: 
        O metodo AddOrUpdateField(string, string) ou AddOrUpdateField(string, double)
        da classe TFirestoreDocument ja cria o TJSONObject interno correto.
        Isso evita o erro 'Invalid class typecast'.
      }
      
      FirestoreDoc.AddOrUpdateField('aluno', FDQuery.FieldByName('Aluno').AsString);
      FirestoreDoc.AddOrUpdateField('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      
      if FDQuery.FieldByName('1ºBim').IsNull then
        ValNota := 0
      else
        ValNota := FDQuery.FieldByName('1ºBim').AsFloat;
      
      FirestoreDoc.AddOrUpdateField('b1_nota', ValNota);
      FirestoreDoc.AddOrUpdateField('situacao', FDQuery.FieldByName('Situacao').AsString);
      
      // Envio Sincrono
      Firestore.InsertOrUpdateDocumentSynchronous(FirestoreDoc);
      
      Inc(Total);
      lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
      
      if Total mod 5 = 0 then
        Application.ProcessMessages;
    except
      on E: Exception do
        lblStatus.Caption := 'Erro registro ' + Total.ToString + ': ' + E.Message;
    end;
    // Nao precisamos dar free no FirestoreDoc aqui se o InsertOrUpdate assumir a gestao, 
    // mas por seguranca, como o metodo Synchronous costuma apenas ler, liberamos a memoria.
    FirestoreDoc.Free; 
    FDQuery.Next;
  end;
  
  FDConnection.Connected := False;
  ShowMessage('Processo concluido! Total: ' + Total.ToString);
  lblStatus.Caption := 'Pronto.';
end;

end.