unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  FB4D.Interfaces,  // Unidade vital para IFirestoreService
  FB4D.Firestore,
  FB4D.Authentication,
  FB4D.Configuration,
  FB4D.Document;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    memLog: TMemo;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    FConfig: IFirebaseConfiguration;
    procedure AddLog(const Msg: string);
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  DATABASE_NAME = '(default)';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // Inicializa Autenticação e Configuração
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
  FConfig := TFirebaseConfiguration.Create(FIREBASE_PROJECT_ID, '', FAuth);
end;

procedure TFormReplicator.AddLog(const Msg: string);
begin
  TThread.Queue(nil, procedure begin
    memLog.Lines.Add(FormatDateTime('hh:nn:ss', Now) + ' - ' + Msg);
    SendMessage(memLog.Handle, WM_VSCROLL, SB_BOTTOM, 0);
  end);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
    Exit;
  end;
  
  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  FirestoreService: IFirestoreService; // Corrigido de IFirestoreDatabase
  FirestoreDoc: IFirestoreDocument;
  Total: Integer;
  sAluno, sDisc, sSit, sNotaStr: string;
begin
  AddLog('--- INICIANDO PROCESSO v18.5 ---');
  try
    // Obtém o serviço do Firestore a partir da configuração
    FirestoreService := FConfig.Firestore; 
    
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
    
    FDQuery.Close;
    FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
    FDQuery.Open;
    AddLog('Registros no SQL: ' + FDQuery.RecordCount.ToString);
    
    Total := 0;
    while not FDQuery.Eof do
    begin
      Inc(Total);
      try
        // Extração de dados com tratamento de nulos
        sAluno := VarToStrDef(FDQuery.FieldByName('Aluno').Value, 'SEM NOME');
        sDisc  := VarToStrDef(FDQuery.FieldByName('Disciplina').Value, 'GERAL');
        sSit   := VarToStrDef(FDQuery.FieldByName('Situacao').Value, 'EM CURSO');
        
        // Formatação de nota para o Firestore (deve usar ponto decimal)
        sNotaStr := StringReplace(FormatFloat('0.00', FDQuery.FieldByName('1ºBim').AsFloat), ',', '.', [rfReplaceAll]);

        // Criar o documento na coleção 'notas_alunos'
        FirestoreDoc := TFirestoreDocument.Create(['notas_alunos'], FIREBASE_PROJECT_ID, DATABASE_NAME);
        
        // Alimentar o documento
        FirestoreDoc.AddOrUpdateField('aluno', TJSONString.Create(sAluno));
        FirestoreDoc.AddOrUpdateField('disciplina', TJSONString.Create(sDisc));
        FirestoreDoc.AddOrUpdateField('situacao', TJSONString.Create(sSit));
        FirestoreDoc.AddOrUpdateField('b1_nota', TJSONNumber.Create(sNotaStr));
        
        // Inserir no Firestore
        // Nota: O método pode variar entre InsertDocumentSynchronous ou InsertOrUpdateDocumentSynchronous
        FirestoreService.InsertDocumentSynchronous(FirestoreDoc, True);
        
        AddLog(Format('[%d] SUCESSO: %s', [Total, sAluno]));

        TThread.Synchronize(nil, procedure begin
           lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
        end);
      except
        on E: Exception do
          AddLog('>> ERRO REGISTRO ' + Total.ToString + ': ' + E.Message);
      end;
      
      FDQuery.Next;
      Application.ProcessMessages;
    end;
    AddLog('--- FIM DO PROCESSO ---');
  except
    on E: Exception do
      AddLog('!!! ERRO FATAL !!! ' + E.Message);
  end;
end;

end.