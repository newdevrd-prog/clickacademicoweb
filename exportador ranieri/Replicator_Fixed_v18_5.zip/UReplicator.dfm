object FormReplicator: TFormReplicator
  Left = 0
  Top = 0
  Caption = 'Replicator v18.5 - FIXED INTERFACES'
  ClientHeight = 600
  ClientWidth = 450
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  TextHeight = 15
  object pnlMain: TPanel
    Left = 0
    Top = 0
    Width = 450
    Height = 600
    Align = alClient
    BevelOuter = bvNone
    TabOrder = 0
    object Label1: TLabel
      Left = 20
      Top = 85
      Width = 166
      Height = 15
      Caption = 'Código da Turma para Replicar:'
    end
    object Label2: TLabel
      Left = 20
      Top = 20
      Width = 143
      Height = 15
      Caption = 'Arquivo do Banco Firebird:'
    end
    object lblStatus: TLabel
      Left = 20
      Top = 195
      Width = 410
      Height = 15
      Alignment = taCenter
      AutoSize = False
      Caption = 'Status: Aguardando'
    end
    object edtCodTurma: TEdit
      Left = 20
      Top = 105
      Width = 410
      Height = 23
      NumbersOnly = True
      TabOrder = 0
    end
    object btnReplicar: TButton
      Left = 20
      Top = 140
      Width = 410
      Height = 45
      Caption = 'SINCRONIZAR AGORA'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Segoe UI'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 1
      OnClick = btnReplicarClick
    end
    object edtCaminhoFDB: TEdit
      Left = 20
      Top = 40
      Width = 325
      Height = 23
      ReadOnly = True
      TabOrder = 2
    end
    object btnProcurarFDB: TButton
      Left = 355
      Top = 39
      Width = 75
      Height = 25
      Caption = 'Procurar...'
      TabOrder = 3
      OnClick = btnProcurarFDBClick
    end
    object memLog: TMemo
      Left = 20
      Top = 220
      Width = 410
      Height = 360
      Color = 2302755
      Font.Charset = ANSI_CHARSET
      Font.Color = clLime
      Font.Height = -11
      Font.Name = 'Consolas'
      Font.Style = []
      ParentFont = False
      ReadOnly = True
      ScrollBars = ssVertical
      TabOrder = 4
    end
  end
  object FDConnection: TFDConnection
    Params.Strings = (
      'DriverID=FB'
      'User_Name=SYSDBA'
      'Password=masterkey'
      'CharacterSet=UTF8')
    LoginPrompt = False
    Left = 360
    Top = 144
  end
  object FDQuery: TFDQuery
    Connection = FDConnection
    SQL.Strings = (
      'Select '
      '  A.NOME as Aluno, D.Nome as Disciplina,'
      '  Media_1b as "1ºBim", S.Nome as Situacao '
      'From NotaAlunoTurma NAT'
      'inner join Situacao S on S.Codigo = NAT.CodigoSituacao'
      'inner join Aluno a on NAT.codigoaluno = A.codigo'
      'inner join Disciplina D on d.codigo = NAT.codigodisciplina'
      'where CodigoTurma = :CodTur'
      'order by A.Nome, D.Codigo')
    Left = 400
    Top = 144
    ParamData = <
      item
        Name = 'CODTUR'
        DataType = ftInteger
        ParamType = ptInput
      end>
  end
  object OpenDialog: TOpenDialog
    DefaultExt = 'fdb'
    Filter = 'Firebird (*.fdb)|*.fdb'
    Left = 360
    Top = 104
  end
  object FDPhysFBDriverLink1: TFDPhysFBDriverLink
    Left = 400
    Top = 104
  end
end