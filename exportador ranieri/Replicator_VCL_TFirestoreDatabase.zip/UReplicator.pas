unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  // Units da FB4D (Firebase for Delphi)
  FB4D.Interfaces, 
  FB4D.Configuration, 
  FB4D.Firestore;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FFirebase: IFirebaseConfiguration;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  // Inicialização da configuração básica
  FFirebase := TFirebaseConfiguration.Create(
    'AIzaSyA2-w2UfVhzN2prqJ2H0kecHYwLTC3XbkU', 
    'clickacademico-342da'
  );
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if edtCaminhoFDB.Text = '' then 
  begin
    ShowMessage('Selecione o arquivo .fdb');
    Exit;
  end;
  
  if edtCodTurma.Text = '' then
  begin
    ShowMessage('Informe o código da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase; 
  DocObj: TJSONObject;
  Total: Integer;
begin
  // Em versões recentes, a classe mudou para TFirestoreDatabase
  // Caso sua versão use método estático: Firestore := TFirestoreDatabase.CreateFirestore(FFirebase);
  Firestore := TFirestoreDatabase.Create(FFirebase);
  
  try 
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    DocObj := TJSONObject.Create;
    try
      DocObj.AddPair('aluno', FDQuery.FieldByName('Aluno').AsString);
      DocObj.AddPair('disciplina', FDQuery.FieldByName('Disciplina').AsString);
      DocObj.AddPair('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
      DocObj.AddPair('situacao', FDQuery.FieldByName('Situacao').AsString);
      
      // Envio para o Firebase
      Firestore.InsertDocument('notas_alunos', '', DocObj);
      
      Inc(Total);
      lblStatus.Caption := 'Enviados: ' + Total.ToString;
      Application.ProcessMessages;
    except
      on E: Exception do
        lblStatus.Caption := 'Erro: ' + E.Message;
    end;
    FDQuery.Next;
  end;
  
  FDConnection.Connected := False;
  ShowMessage('Processo concluído!');
end;

end.