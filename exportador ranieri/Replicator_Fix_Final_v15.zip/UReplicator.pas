unit UReplicator;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.FB, FireDAC.Phys.FBDef,
  FireDAC.VCLUI.Wait, Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet,
  System.JSON,
  FB4D.Interfaces, 
  FB4D.Firestore,
  FB4D.Authentication,
  FB4D.Document;

type
  TFormReplicator = class(TForm)
    FDConnection: TFDConnection;
    FDQuery: TFDQuery;
    btnReplicar: TButton;
    edtCodTurma: TEdit;
    Label1: TLabel;
    pnlMain: TPanel;
    lblStatus: TLabel;
    OpenDialog: TOpenDialog;
    btnProcurarFDB: TButton;
    edtCaminhoFDB: TEdit;
    Label2: TLabel;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    procedure btnReplicarClick(Sender: TObject);
    procedure btnProcurarFDBClick(Sender: TObject);
  private
    FAuth: IFirebaseAuthentication;
    procedure ReplicarParaFirebase;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  FormReplicator: TFormReplicator;

const
  FIREBASE_PROJECT_ID = 'clickacademico-342da';
  DATABASE_NAME = '(default)';

implementation

{$R *.dfm}

constructor TFormReplicator.Create(AOwner: TComponent);
begin
  inherited;
  FAuth := TFirebaseAuthentication.Create(FIREBASE_PROJECT_ID);
end;

procedure TFormReplicator.btnProcurarFDBClick(Sender: TObject);
begin
  if OpenDialog.Execute then
    edtCaminhoFDB.Text := OpenDialog.FileName;
end;

procedure TFormReplicator.btnReplicarClick(Sender: TObject);
begin
  if (edtCaminhoFDB.Text = '') or (not FileExists(edtCaminhoFDB.Text)) then 
  begin
    ShowMessage('Selecione o arquivo do banco de dados Firebird (.fdb)');
    Exit;
  end;
  
  if Trim(edtCodTurma.Text) = '' then
  begin
    ShowMessage('Informe o codigo da turma.');
    Exit;
  end;

  btnReplicar.Enabled := False;
  try
    ReplicarParaFirebase;
  finally
    btnReplicar.Enabled := True;
  end;
end;

procedure TFormReplicator.ReplicarParaFirebase;
var
  Firestore: IFirestoreDatabase;
  FirestoreDoc: IFirestoreDocument;
  Total: Integer;
begin
  Firestore := TFirestoreDatabase.Create(DATABASE_NAME, FAuth);
  
  try 
    FDConnection.Close;
    FDConnection.Params.Values['Database'] := edtCaminhoFDB.Text;
    FDConnection.Connected := True; 
  except 
    on E: Exception do begin
      ShowMessage('Erro Firebird: ' + E.Message);
      Exit; 
    end;
  end;

  FDQuery.Close;
  FDQuery.ParamByName('CodTur').AsInteger := StrToIntDef(edtCodTurma.Text, 0);
  FDQuery.Open;
  
  Total := 0;
  while not FDQuery.Eof do
  begin
    // Criamos o documento conforme FB4D.Document
    FirestoreDoc := TFirestoreDocument.Create(['notas_alunos'], FIREBASE_PROJECT_ID, DATABASE_NAME);
    
    try
      { 
        V15: Usando AddOrUpdateField com TJSONValue diretamente.
        Esta e a forma mais básica e compatível com todas as versões da FB4D.
      }
      
      FirestoreDoc.AddOrUpdateField('aluno', TJSONString.Create(FDQuery.FieldByName('Aluno').AsString));
      FirestoreDoc.AddOrUpdateField('disciplina', TJSONString.Create(FDQuery.FieldByName('Disciplina').AsString));
      
      if FDQuery.FieldByName('1ºBim').IsNull then
        FirestoreDoc.AddOrUpdateField('b1_nota', TJSONNumber.Create(0))
      else
        FirestoreDoc.AddOrUpdateField('b1_nota', TJSONNumber.Create(FDQuery.FieldByName('1ºBim').AsFloat));
        
      FirestoreDoc.AddOrUpdateField('situacao', TJSONString.Create(FDQuery.FieldByName('Situacao').AsString));
      
      // Envio síncrono
      Firestore.InsertOrUpdateDocumentSynchronous(FirestoreDoc);
      
      Inc(Total);
      lblStatus.Caption := 'Sincronizados: ' + Total.ToString;
      if Total mod 5 = 0 then Application.ProcessMessages;
    except
      on E: Exception do
        lblStatus.Caption := 'Erro: ' + E.Message;
    end;
    
    FDQuery.Next;
  end;
  
  FDConnection.Connected := False;
  ShowMessage('Processo Finalizado v15! Total: ' + Total.ToString);
end;

end.